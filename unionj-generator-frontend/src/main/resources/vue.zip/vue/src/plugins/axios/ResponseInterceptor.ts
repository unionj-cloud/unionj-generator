import type {AxiosResponse} from "axios"

export default (response: AxiosResponse): any => {
  // TODO
  // add your logic here
  return response.data
}
