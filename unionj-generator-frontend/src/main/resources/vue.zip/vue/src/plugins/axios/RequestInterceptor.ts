import type {AxiosRequestConfig} from "axios"

export default (config: AxiosRequestConfig): AxiosRequestConfig => {
  // TODO
  // add your logic here
  return config
}
