declare module "vue2-waterfall";

